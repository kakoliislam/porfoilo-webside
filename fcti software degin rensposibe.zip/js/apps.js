var bars=document.getElementById('bars');
var cross=document.getElementById('cross');

bars.addEventListener('click',function(){
	var menuItems=document.querySelector('.menu-items');
	menuItems.classList.toggle('active');
})
cross.addEventListener('click',function(){
	var menuItems=document.querySelector('.menu-items');
	menuItems.classList.remove('active');
})
// sticky navbar javascript code below here
window.addEventListener('scroll',function(){
    const navbarSticky=document.querySelector('.container');
    navbarSticky.classList.toggle("sticky",window.scrollY>0);

});


const swiper = new Swiper('.swiper',{
	autoplay:{
		display:3000,
		disableOnInteraction:false,
	},
  loop: true,
  pagination: {
    el: '.swiper-pagination',
	clickable:true,
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },


});
// Fixed Resize Screen Function
window.addEventListener('resize', () => {
	if (this.innerWidth > 991) {
		// If navbarMenu is Open, then Close It
		if (navbarMenu.classList.contains('active')) {
			toggleMenu();
		}

		// If menu-item-child is Expanded, then Collapse It
		if (navbarMenu.querySelector('.menu-item-child.active')) {
			collapseSubMenu();
		}
	}
});
//top button section js code

const scrollTopBtn=document.getElementById('scrollTopBtn');
window.onscroll=function(){

    if(document.documentElement.scrollTop>70){
        scrollTopBtn.style.display="block";
       
    }else{
        scrollTopBtn.style.display="none";
    }
   
}
scrollTopBtn.addEventListener('click',()=>{
    window.scrollTo(0,0);//one way
    document.documentElement.scrollTop=0; //two way
});






